#include "hw03.h"

void printConvertedTime(std::string time) {
	std::cout << "Converted time: " << time << "\n";
}
