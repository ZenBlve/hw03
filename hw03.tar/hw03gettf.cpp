#include "hw03.h"

std::string getTimeTwentyFourHour() {
	std::string time;
	std::cout << "Enter time in 24-hour notation: ";
	std::cin >> time;
	return time;
}
