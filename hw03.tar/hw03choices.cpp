#include "hw03.h"

void showChoices() {
std::cout << "Time Conversion Menu:\n";
std::cout << "1. Convert 12-hour to 24-hour time notation\n";
std::cout << "2. Convert 24-hour to 12-hour time notaiton\n";
std::cout << "Enter your choice (1 or 2): ";
}
