#include "hw03.h"

std::string getTimeTwelveHour() {
	std::string time;
	std::cout << "Enter time in a 12-hour notation: ";
	std::cin >> time;
	return time;
}
